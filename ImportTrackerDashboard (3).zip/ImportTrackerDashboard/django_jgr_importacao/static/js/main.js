// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Inicializar popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // Tornar mensagens de alerta autodismissíveis após 5 segundos
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Lidar com a cópia de links de compartilhamento
    var copyButtons = document.querySelectorAll('.copy-link-btn');
    copyButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var linkText = this.closest('.share-link-box').querySelector('.share-url').textContent;
            
            navigator.clipboard.writeText(linkText.trim()).then(function() {
                var originalText = button.innerHTML;
                button.innerHTML = '<i class="bi bi-check"></i> Copiado!';
                button.classList.remove('btn-primary');
                button.classList.add('btn-success');
                
                setTimeout(function() {
                    button.innerHTML = originalText;
                    button.classList.remove('btn-success');
                    button.classList.add('btn-primary');
                }, 2000);
            }).catch(function(err) {
                console.error('Não foi possível copiar o texto: ', err);
                alert('Não foi possível copiar o texto. Por favor, selecione e copie manualmente.');
            });
        });
    });

    // Formatação de campos de data na tabela
    var dateElements = document.querySelectorAll('.format-date');
    dateElements.forEach(function(element) {
        var dateStr = element.textContent.trim();
        if (dateStr && dateStr !== 'None' && dateStr !== '') {
            try {
                var date = new Date(dateStr);
                if (!isNaN(date.getTime())) {
                    element.textContent = date.toLocaleDateString('pt-BR');
                }
            } catch (e) {
                console.error('Erro ao formatar data:', e);
            }
        }
    });

    // Adicionar classe 'active' ao link de navegação atual
    var currentUrl = window.location.pathname;
    var navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(function(link) {
        var href = link.getAttribute('href');
        if (href === currentUrl || (href !== '/' && currentUrl.startsWith(href))) {
            link.classList.add('active');
        }
    });

    // Confirmação para ações destrutivas
    var confirmForms = document.querySelectorAll('form[data-confirm]');
    confirmForms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            var confirmMessage = this.getAttribute('data-confirm');
            if (!confirm(confirmMessage)) {
                e.preventDefault();
                return false;
            }
        });
    });
});