from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from django.db.models import Q
from django.urls import reverse
import uuid
from datetime import datetime, timedelta

from .models import Process, Event, ShareLink
from .forms import ProcessForm, EventForm, CustomUserCreationForm, ShareLinkForm, FilterProcessForm
from .utils import export_to_excel, export_to_csv, generate_unique_id, check_and_update_period
from .event_templates import get_event_template

# Views principais

@login_required
def home(request):
    """Página inicial com lista de processos"""
    form = FilterProcessForm(request.GET)
    
    # Filtrar processos
    processes = Process.objects.all().order_by('-last_update')
    
    # Verificar e atualizar períodos automaticamente para todos os processos
    # Isso só será executado para administradores para evitar mudanças paralelas
    if request.user.is_staff:
        updated_processes = []
        for process in processes:
            if process.current_period_expiry and process.current_period_start:
                updated, new_expiry = check_and_update_period(process)
                if updated:
                    updated_processes.append({
                        'id': process.id,
                        'new_start': process.current_period_start.strftime('%d/%m/%Y'),
                        'new_expiry': new_expiry.strftime('%d/%m/%Y')
                    })
        
        # Se algum período foi atualizado, mostrar mensagem
        if updated_processes:
            if len(updated_processes) == 1:
                process_info = updated_processes[0]
                messages.info(
                    request, 
                    f"O período do processo {process_info['id']} foi atualizado automaticamente. "
                    f"Novo período: {process_info['new_start']} - {process_info['new_expiry']}"
                )
            else:
                messages.info(
                    request, 
                    f"{len(updated_processes)} processos tiveram seus períodos atualizados automaticamente."
                )
    
    # Apenas administradores veem todos os processos, clientes só veem os seus
    if not request.user.is_staff:
        processes = processes.filter(client=request.user)
    
    # Aplicar filtros se o formulário foi submetido
    if form.is_valid():
        # Filtro de texto (busca em vários campos)
        search = form.cleaned_data.get('search')
        if search:
            processes = processes.filter(
                Q(id__icontains=search) | 
                Q(ref__icontains=search) | 
                Q(po__icontains=search) | 
                Q(container__icontains=search) | 
                Q(invoice__icontains=search) | 
                Q(product__icontains=search)
            )
        
        # Filtro de status
        status = form.cleaned_data.get('status')
        if status:
            processes = processes.filter(status=status)
        
        # Filtro de cliente (apenas para administradores)
        client = form.cleaned_data.get('client')
        if client and request.user.is_staff:
            processes = processes.filter(client=client)
    
    context = {
        'processes': processes,
        'form': form,
    }
    return render(request, 'importacao/home.html', context)


@login_required
def process_detail(request, pk):
    """Visualização detalhada de um processo"""
    process = get_object_or_404(Process, id=pk)
    
    # Verificar permissão: administradores podem ver qualquer processo, 
    # clientes só podem ver os seus
    if not request.user.is_staff and process.client != request.user:
        messages.error(request, "Você não tem permissão para visualizar este processo.")
        return redirect('home')
    
    # Verificar e atualizar o período se necessário (apenas para admin)
    if request.user.is_staff and process.current_period_expiry and process.current_period_start:
        updated, new_expiry = check_and_update_period(process)
        if updated:
            new_start_fmt = process.current_period_start.strftime('%d/%m/%Y')
            new_expiry_fmt = new_expiry.strftime('%d/%m/%Y')
            messages.info(
                request, 
                f"O período foi atualizado automaticamente. Novo período: {new_start_fmt} - {new_expiry_fmt}"
            )
    
    # Formulário para adicionar evento
    if request.method == 'POST':
        event_form = EventForm(request.POST)
        if event_form.is_valid():
            event = event_form.save(commit=False)
            event.process = process
            event.user = request.user
            event.save()
            messages.success(request, "Evento adicionado com sucesso!")
            return redirect('process_detail', pk=pk)
    else:
        event_form = EventForm()
    
    # Filtrar eventos (para clientes, ocultar eventos de atribuição)
    events = process.events.all().order_by('-date')
    if not request.user.is_staff:
        events = events.exclude(
            Q(description__icontains='atribuído ao cliente') | 
            Q(description__icontains='removido do cliente')
        )
    
    context = {
        'process': process,
        'events': events,
        'event_form': event_form,
    }
    return render(request, 'importacao/process_detail.html', context)


@staff_member_required
def process_create(request):
    """Criar novo processo"""
    if request.method == 'POST':
        form = ProcessForm(request.POST)
        if form.is_valid():
            process = form.save(commit=False)
            
            # Gerar ID único se não foi fornecido
            if not process.id:
                process.id = generate_unique_id()
            
            process.save()
            
            # Registrar evento de criação
            Event.objects.create(
                process=process,
                description="Processo criado",
                user=request.user
            )
            
            messages.success(request, f"Processo {process.id} criado com sucesso!")
            return redirect('process_detail', pk=process.id)
    else:
        # Inicializar com um ID sugerido
        form = ProcessForm(initial={'id': generate_unique_id()})
    
    context = {
        'form': form,
        'title': 'Novo Processo',
    }
    return render(request, 'importacao/process_form.html', context)


@staff_member_required
def process_update(request, pk):
    """Atualizar processo existente"""
    process = get_object_or_404(Process, id=pk)
    
    if request.method == 'POST':
        form = ProcessForm(request.POST, instance=process)
        if form.is_valid():
            form.save()
            
            # Registrar evento de atualização
            Event.objects.create(
                process=process,
                description="Processo atualizado",
                user=request.user
            )
            
            messages.success(request, f"Processo {process.id} atualizado com sucesso!")
            return redirect('process_detail', pk=process.id)
    else:
        form = ProcessForm(instance=process)
    
    context = {
        'form': form,
        'title': f'Editar Processo {process.id}',
        'process': process,
    }
    return render(request, 'importacao/process_form.html', context)


@staff_member_required
def process_delete(request, pk):
    """Excluir processo"""
    process = get_object_or_404(Process, id=pk)
    
    if request.method == 'POST':
        process_id = process.id
        process.delete()
        messages.success(request, f"Processo {process_id} excluído com sucesso!")
        return redirect('home')
    
    context = {
        'process': process,
    }
    return render(request, 'importacao/process_confirm_delete.html', context)


# Views de usuários e clientes

@staff_member_required
def user_list(request):
    """Listar usuários"""
    users = User.objects.all().order_by('-is_staff', 'username')
    
    context = {
        'users': users,
    }
    return render(request, 'importacao/user_list.html', context)


@staff_member_required
def user_create(request):
    """Criar novo usuário"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            
            # Definir tipo de usuário (admin ou cliente)
            role = form.cleaned_data.get('role')
            user.is_staff = (role == 'admin')
            
            user.save()
            messages.success(request, f"Usuário {user.username} criado com sucesso!")
            return redirect('user_list')
    else:
        form = CustomUserCreationForm()
    
    context = {
        'form': form,
        'title': 'Novo Usuário',
    }
    return render(request, 'importacao/user_form.html', context)


@staff_member_required
def assign_process(request, pk):
    """Atribuir processo a um cliente"""
    process = get_object_or_404(Process, id=pk)
    clients = User.objects.filter(is_staff=False)
    
    if request.method == 'POST':
        client_id = request.POST.get('client')
        
        # Remover atribuição se for "None"
        if client_id == 'None':
            old_client = process.client
            process.client = None
            process.save()
            
            if old_client:
                # Registrar evento de remoção
                Event.objects.create(
                    process=process,
                    description=f"Processo removido do cliente {old_client.get_full_name() or old_client.username}",
                    user=request.user
                )
                
            messages.success(request, "Processo desvinculado de cliente com sucesso!")
        else:
            # Atribuir a novo cliente
            client = get_object_or_404(User, id=client_id)
            old_client = process.client
            process.client = client
            process.save()
            
            # Registrar evento de atribuição
            Event.objects.create(
                process=process,
                description=f"Processo atribuído ao cliente {client.get_full_name() or client.username}",
                user=request.user
            )
            
            messages.success(request, f"Processo atribuído a {client.get_full_name() or client.username} com sucesso!")
        
        return redirect('process_detail', pk=pk)
    
    context = {
        'process': process,
        'clients': clients,
    }
    return render(request, 'importacao/assign_process.html', context)


# Views de compartilhamento

@staff_member_required
def share_link_create(request):
    """Criar link de compartilhamento"""
    if request.method == 'POST':
        form = ShareLinkForm(request.POST)
        if form.is_valid():
            process = form.cleaned_data.get('process')
            expiry_days = form.cleaned_data.get('expiry_days')
            
            # Gerar token único
            token = uuid.uuid4().hex
            
            # Calcular data de expiração
            expires_at = timezone.now() + timedelta(days=expiry_days)
            
            # Criar link de compartilhamento
            share_link = ShareLink.objects.create(
                process=process,
                token=token,
                expires_at=expires_at
            )
            
            # Montar URL completa
            share_url = request.build_absolute_uri(
                reverse('shared_process', args=[token])
            )
            
            messages.success(request, "Link de compartilhamento criado com sucesso!")
            context = {
                'share_link': share_link,
                'share_url': share_url,
            }
            return render(request, 'importacao/share_link_success.html', context)
    else:
        form = ShareLinkForm()
    
    context = {
        'form': form,
    }
    return render(request, 'importacao/share_link_form.html', context)


def shared_process(request, token):
    """Visualizar processo através de link compartilhado"""
    # Verificar se o token existe e é válido
    share_link = get_object_or_404(ShareLink, token=token)
    
    # Verificar se o link expirou ou foi desativado
    if not share_link.is_active or share_link.expires_at < timezone.now():
        return render(request, 'importacao/share_expired.html')
    
    process = share_link.process
    
    # Filtrar eventos (ocultar eventos de atribuição)
    events = process.events.all().order_by('-date')
    events = events.exclude(
        Q(description__icontains='atribuído ao cliente') | 
        Q(description__icontains='removido do cliente')
    )
    
    context = {
        'process': process,
        'events': events,
        'share_link': share_link,
        'is_shared_view': True,
    }
    return render(request, 'importacao/shared_process.html', context)


@staff_member_required
def share_link_list(request):
    """Listar links de compartilhamento"""
    share_links = ShareLink.objects.all().order_by('-created_at')
    
    context = {
        'share_links': share_links,
    }
    return render(request, 'importacao/share_link_list.html', context)


@staff_member_required
def share_link_deactivate(request, pk):
    """Desativar link de compartilhamento"""
    share_link = get_object_or_404(ShareLink, id=pk)
    
    if request.method == 'POST':
        share_link.is_active = False
        share_link.save()
        messages.success(request, "Link de compartilhamento desativado com sucesso!")
        return redirect('share_link_list')
    
    context = {
        'share_link': share_link,
    }
    return render(request, 'importacao/share_link_confirm_deactivate.html', context)


# View para atualização rápida de status

@staff_member_required
def quick_status_update(request, pk):
    """Atualizar rapidamente o status de um processo com evento predefinido"""
    process = get_object_or_404(Process, id=pk)
    
    if request.method == 'POST':
        # Obter o novo status
        new_status = request.POST.get('status')
        if not new_status:
            messages.error(request, "Status não especificado.")
            return redirect('process_detail', pk=pk)
        
        # Obter parâmetros adicionais para o evento
        params = {}
        
        # Para status que exigem datas
        if new_status in ['chegando_porto_santos', 'chegada_navio_alterada']:
            eta_str = request.POST.get('eta')
            if eta_str:
                try:
                    eta_date = datetime.strptime(eta_str, '%Y-%m-%d').date()
                    params['eta'] = eta_date.strftime('%d/%m/%Y')
                    # Atualizar também o ETA do processo
                    process.eta = eta_date
                except ValueError:
                    messages.warning(request, "Formato de data inválido. Usando data do processo.")
                    if process.eta:
                        params['eta'] = process.eta.strftime('%d/%m/%Y')
            elif process.eta:
                params['eta'] = process.eta.strftime('%d/%m/%Y')
        
        elif new_status == 'rota_transito_aduaneiro':
            params['destination'] = request.POST.get('destination', 'destino não especificado')
        
        elif new_status == 'entrega_programada':
            delivery_date_str = request.POST.get('delivery_date')
            if delivery_date_str:
                try:
                    delivery_date = datetime.strptime(delivery_date_str, '%Y-%m-%d').date()
                    params['delivery_date'] = delivery_date.strftime('%d/%m/%Y')
                except ValueError:
                    messages.warning(request, "Formato de data inválido para entrega.")
                    params['delivery_date'] = 'data a confirmar'
            else:
                params['delivery_date'] = 'data a confirmar'
        
        # Atualizar o status do processo
        old_status = process.get_status_display()
        process.status = new_status
        process.save()
        
        # Criar evento usando o template
        event_description = get_event_template(new_status, **params)
        Event.objects.create(
            process=process,
            description=event_description,
            user=request.user
        )
        
        messages.success(request, f"Status atualizado de '{old_status}' para '{process.get_status_display()}'.")
        return redirect('process_detail', pk=pk)
    
    # Se não for POST, mostrar formulário
    # Usar os status agrupados definidos no ProcessForm
    from .forms import ProcessForm
    
    context = {
        'process': process,
        'status_choices': Process.STATUS_CHOICES,
        'status_choices_grouped': ProcessForm.STATUS_CHOICES_GROUPED,
    }
    return render(request, 'importacao/quick_status_update.html', context)


# Views de exportação

@staff_member_required
def export_processes(request):
    """Exportar processos para Excel ou CSV"""
    processes = Process.objects.all().order_by('-last_update')
    
    # Aplicar filtros se fornecidos
    search = request.GET.get('search')
    status = request.GET.get('status')
    client_id = request.GET.get('client')
    
    if search:
        processes = processes.filter(
            Q(id__icontains=search) | 
            Q(ref__icontains=search) | 
            Q(po__icontains=search) | 
            Q(container__icontains=search) | 
            Q(invoice__icontains=search) | 
            Q(product__icontains=search)
        )
    
    if status:
        processes = processes.filter(status=status)
    
    if client_id:
        processes = processes.filter(client_id=client_id)
    
    # Escolher formato de exportação
    export_format = request.GET.get('format', 'excel')
    
    if export_format == 'excel':
        output = export_to_excel(processes)
        response = HttpResponse(
            output.read(),
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename=processos.xlsx'
    else:  # CSV
        output = export_to_csv(processes)
        response = HttpResponse(output.read(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=processos.csv'
    
    return response