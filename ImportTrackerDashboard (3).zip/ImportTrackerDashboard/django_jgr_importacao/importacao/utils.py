from datetime import datetime, timedelta
from django.utils import timezone
import uuid
import os
from io import BytesIO
import xlsxwriter
import csv

def format_date(date_obj):
    """Formata data para DD/MM/YYYY"""
    if not date_obj:
        return ""
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.strptime(date_obj, "%Y-%m-%d").date()
        except ValueError:
            return date_obj
    return date_obj.strftime("%d/%m/%Y")

def calculate_free_time_expiry(eta_date, free_time_days):
    """Calcula data de expiração do free time baseado no ETA e dias de free time"""
    if not eta_date or not free_time_days:
        return None
    
    if isinstance(eta_date, str):
        try:
            eta_date = datetime.strptime(eta_date, "%Y-%m-%d").date()
        except ValueError:
            return None
    
    free_time_days = int(free_time_days)
    return eta_date + timedelta(days=free_time_days)

def calculate_period_expiry(start_date, days_per_period):
    """Calcula data de expiração do período baseado na data inicial e dias por período"""
    if not start_date:
        return None
    
    if isinstance(start_date, str):
        try:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        except ValueError:
            return None
    
    days_per_period = int(days_per_period) if days_per_period else 10  # Padrão: 10 dias
    return start_date + timedelta(days=days_per_period)

def calculate_storage_days(entry_date):
    """Calcula dias de armazenagem da data de entrada até hoje"""
    if not entry_date:
        return 0
    
    if isinstance(entry_date, str):
        try:
            entry_date = datetime.strptime(entry_date, "%Y-%m-%d").date()
        except ValueError:
            return 0
    
    today = timezone.now().date()
    return (today - entry_date).days

def get_status_color(status):
    """Obtém cor para indicador de status"""
    status = status.lower() if status else ""
    
    # Status padrão
    if "concluído" in status or "concluido" in status:
        return "#28a745"  # Verde
    elif "atrasado" in status:
        return "#dc3545"  # Vermelho
    elif "pendente" in status:
        return "#ffc107"  # Amarelo
    elif "cancelado" in status:
        return "#6c757d"  # Cinza
    
    # Novos status específicos
    elif "novo processo" in status:
        return "#17a2b8"  # Ciano
    elif "navio em santos" in status:
        return "#9c27b0"  # Roxo
    elif "chegando no porto" in status:
        return "#3f51b5"  # Índigo
    elif "chegada do navio alterada" in status:
        return "#ff9800"  # Laranja
    elif "transito aduaneiro" in status:
        return "#4caf50"  # Verde mais claro
    elif "em rota" in status:
        return "#2196f3"  # Azul claro
    elif "presença de carga" in status:
        return "#009688"  # Verde água
    elif "entrega programada" in status:
        return "#8bc34a"  # Verde limão
    
    # Padrão para qualquer outro status (em andamento)
    else:
        return "#007bff"  # Azul
    
def get_status_from_dates(date_str, expected_date_str):
    """Determina status baseado nas datas"""
    if not date_str or not expected_date_str:
        return "Em andamento"
    
    try:
        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        expected_date = datetime.strptime(expected_date_str, "%Y-%m-%d").date()
        today = timezone.now().date()
        
        if date_obj <= today <= expected_date:
            return "Em andamento"
        elif today > expected_date:
            return "Atrasado"
        else:
            return "Pendente"
    except (ValueError, TypeError):
        return "Em andamento"

def generate_unique_id():
    """Gera um ID único para processos"""
    # Formato: JGR-YYYY-XXXXX (Ano atual + 5 caracteres aleatórios)
    year = datetime.now().year
    random_part = uuid.uuid4().hex[:5].upper()
    return f"JGR-{year}-{random_part}"

def export_to_excel(processes):
    """Exporta processos para Excel"""
    output = BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()
    
    # Estilos
    header_format = workbook.add_format({
        'bold': True,
        'bg_color': '#0066cc',
        'color': 'white',
        'align': 'center',
        'valign': 'vcenter',
        'border': 1
    })
    
    cell_format = workbook.add_format({
        'align': 'left',
        'valign': 'vcenter',
        'border': 1
    })
    
    date_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'border': 1,
        'num_format': 'dd/mm/yyyy'
    })
    
    # Cabeçalhos
    headers = [
        'Código', 'Referência', 'PO', 'Status', 'Origem', 'Produto', 
        'ETA', 'Free Time', 'Free Time Expiração', 'Entrada no Porto', 
        'Container', 'Mapa', 'Invoice', 'Dias Armazenados'
    ]
    
    for col, header in enumerate(headers):
        worksheet.write(0, col, header, header_format)
    
    # Dados
    for row, process in enumerate(processes, start=1):
        col = 0
        worksheet.write(row, col, process.id, cell_format); col += 1
        worksheet.write(row, col, process.ref or '', cell_format); col += 1
        worksheet.write(row, col, process.po or '', cell_format); col += 1
        worksheet.write(row, col, process.get_status_display(), cell_format); col += 1
        worksheet.write(row, col, process.origin or '', cell_format); col += 1
        worksheet.write(row, col, process.product or '', cell_format); col += 1
        
        if process.eta:
            worksheet.write_datetime(row, col, process.eta, date_format); col += 1
        else:
            worksheet.write(row, col, '', cell_format); col += 1
            
        worksheet.write(row, col, process.free_time or '', cell_format); col += 1
        
        if process.free_time_expiry:
            worksheet.write_datetime(row, col, process.free_time_expiry, date_format); col += 1
        else:
            worksheet.write(row, col, '', cell_format); col += 1
            
        if process.port_entry_date:
            worksheet.write_datetime(row, col, process.port_entry_date, date_format); col += 1
        else:
            worksheet.write(row, col, '', cell_format); col += 1
            
        worksheet.write(row, col, process.container or '', cell_format); col += 1
        worksheet.write(row, col, process.map or '', cell_format); col += 1
        worksheet.write(row, col, process.invoice or '', cell_format); col += 1
        worksheet.write(row, col, process.storage_days or 0, cell_format); col += 1
    
    # Ajustar largura das colunas
    for col, header in enumerate(headers):
        worksheet.set_column(col, col, max(len(header) + 2, 12))
    
    workbook.close()
    output.seek(0)
    
    return output

def export_to_csv(processes):
    """Exporta processos para CSV"""
    output = BytesIO()
    fieldnames = [
        'id', 'ref', 'po', 'status', 'origin', 'product', 
        'eta', 'free_time', 'free_time_expiry', 'port_entry_date', 
        'container', 'map', 'invoice', 'storage_days'
    ]
    
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    
    for process in processes:
        writer.writerow({
            'id': process.id,
            'ref': process.ref or '',
            'po': process.po or '',
            'status': process.get_status_display(),
            'origin': process.origin or '',
            'product': process.product or '',
            'eta': format_date(process.eta) if process.eta else '',
            'free_time': process.free_time or '',
            'free_time_expiry': format_date(process.free_time_expiry) if process.free_time_expiry else '',
            'port_entry_date': format_date(process.port_entry_date) if process.port_entry_date else '',
            'container': process.container or '',
            'map': process.map or '',
            'invoice': process.invoice or '',
            'storage_days': process.storage_days or 0,
        })
    
    output.seek(0)
    return output

def check_and_update_period(process, days_per_period=10):
    """
    Verifica se a data de vencimento do período atual é hoje.
    Se for, atualiza a data de início do período para hoje e recalcula a data de vencimento.
    
    Args:
        process: O objeto Process a ser verificado e atualizado
        days_per_period: Número de dias para o novo período (padrão: 10)
        
    Returns:
        bool: True se o período foi atualizado, False caso contrário
        datetime.date: A nova data de vencimento se foi atualizado, None caso contrário
    """
    today = timezone.now().date()
    
    # Se a data de vencimento do período atual é hoje ou já passou
    if process.current_period_expiry and process.current_period_expiry <= today:
        old_start = process.current_period_start
        old_expiry = process.current_period_expiry
        
        # Atualiza a data de início do período para hoje
        process.current_period_start = today
        # Recalcula a data de vencimento do período
        process.current_period_expiry = calculate_period_expiry(today, days_per_period)
        
        # Registra um evento para a atualização do período
        from django.contrib.auth.models import User
        from .models import Event
        
        # Formatar datas para a mensagem
        old_start_fmt = format_date(old_start)
        old_expiry_fmt = format_date(old_expiry)
        new_start_fmt = format_date(today)
        new_expiry_fmt = format_date(process.current_period_expiry)
        
        # Criar evento
        Event.objects.create(
            process=process,
            description=f"Período atualizado automaticamente. Período anterior: {old_start_fmt} - {old_expiry_fmt}. "
                        f"Novo período: {new_start_fmt} - {new_expiry_fmt}.",
            user=None  # Sistema
        )
        
        # Atualiza o Process
        process.save(update_fields=['current_period_start', 'current_period_expiry'])
        
        return True, process.current_period_expiry
    
    return False, None