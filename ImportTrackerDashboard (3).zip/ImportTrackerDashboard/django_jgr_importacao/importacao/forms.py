from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Process, Event, ShareLink
from .utils import calculate_free_time_expiry, calculate_period_expiry, calculate_storage_days

class ProcessForm(forms.ModelForm):
    """Formulário para adicionar/editar processo de importação"""
    
    # Status agrupados por categorias para o dropdown
    STATUS_CHOICES_GROUPED = [
        ('Status Básicos', [
            ('em_andamento', 'Em andamento'),
            ('concluido', 'Concluído'),
            ('pendente', 'Pendente'),
            ('atrasado', 'Atrasado'),
            ('cancelado', 'Cancelado'),
        ]),
        ('Status de Importação', [
            ('novo_processo', 'Novo Processo'),
            ('navio_em_santos', 'Navio em Santos'),
            ('chegando_porto_santos', 'Chegando no porto de Santos'),
            ('chegada_navio_alterada', 'Chegada do navio alterada'),
            ('transito_aduaneiro', 'Trânsito Aduaneiro'),
            ('rota_transito_aduaneiro', 'Em rota de trânsito aduaneiro'),
            ('presenca_carga_bauru', 'Presença de carga em Bauru'),
            ('entrega_programada', 'Entrega programada'),
        ]),
    ]
    
    # Substituir o field de status padrão por um com grupos
    status = forms.ChoiceField(
        choices=STATUS_CHOICES_GROUPED,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    class Meta:
        model = Process
        exclude = ['created_at', 'last_update']
        widgets = {
            'observations': forms.Textarea(attrs={'rows': 4}),
            'eta': forms.DateInput(attrs={'type': 'date'}),
            'arrival_date': forms.DateInput(attrs={'type': 'date'}),
            'free_time_expiry': forms.DateInput(attrs={'type': 'date', 'readonly': True}),
            'empty_return': forms.DateInput(attrs={'type': 'date'}),
            'port_entry_date': forms.DateInput(attrs={'type': 'date'}),
            'current_period_start': forms.DateInput(attrs={'type': 'date'}),
            'current_period_expiry': forms.DateInput(attrs={'type': 'date', 'readonly': True}),
            'return_date': forms.DateInput(attrs={'type': 'date'}),
            'storage_days': forms.NumberInput(attrs={'readonly': True}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        
        # Calcular campos derivados automaticamente
        eta = cleaned_data.get('eta')
        free_time = cleaned_data.get('free_time')
        port_entry_date = cleaned_data.get('port_entry_date')
        current_period_start = cleaned_data.get('current_period_start')
        
        # Calcular vencimento do free time
        if eta and free_time:
            cleaned_data['free_time_expiry'] = calculate_free_time_expiry(eta, free_time)
        
        # Calcular vencimento do período (assumindo período de 10 dias)
        if current_period_start:
            cleaned_data['current_period_expiry'] = calculate_period_expiry(current_period_start, 10)
        
        # Calcular dias de armazenagem
        if port_entry_date:
            cleaned_data['storage_days'] = calculate_storage_days(port_entry_date)
        
        return cleaned_data


class EventForm(forms.ModelForm):
    """Formulário para adicionar eventos"""
    
    class Meta:
        model = Event
        fields = ['description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }


class CustomUserCreationForm(UserCreationForm):
    """Formulário personalizado para criação de usuários"""
    
    ROLE_CHOICES = [
        ('client', 'Cliente'),
        ('admin', 'Administrador'),
    ]
    
    role = forms.ChoiceField(choices=ROLE_CHOICES, label="Tipo de Usuário")
    
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


class ShareLinkForm(forms.Form):
    """Formulário para gerar links de compartilhamento"""
    
    process = forms.ModelChoiceField(
        queryset=Process.objects.all(),
        label="Processo"
    )
    expiry_days = forms.IntegerField(
        min_value=1,
        max_value=90,
        initial=30,
        label="Dias de validade"
    )


class FilterProcessForm(forms.Form):
    """Formulário para filtrar processos"""
    
    # Usar a mesma lógica de grupos de status do ProcessForm
    _status_choices = ProcessForm.STATUS_CHOICES_GROUPED.copy()
    
    # Adicionar opção "Todos" como primeira opção
    STATUS_CHOICES_FLAT = [('', 'Todos')]
    for group, choices in _status_choices:
        for value, label in choices:
            STATUS_CHOICES_FLAT.append((value, label))
    
    search = forms.CharField(
        required=False,
        label="Buscar",
        widget=forms.TextInput(attrs={'placeholder': 'Buscar por ID, referência, PO...'})
    )
    status = forms.ChoiceField(
        required=False,
        choices=STATUS_CHOICES_FLAT,
        label="Status"
    )
    client = forms.ModelChoiceField(
        required=False,
        queryset=User.objects.filter(is_staff=False),
        label="Cliente",
        empty_label="Todos"
    )