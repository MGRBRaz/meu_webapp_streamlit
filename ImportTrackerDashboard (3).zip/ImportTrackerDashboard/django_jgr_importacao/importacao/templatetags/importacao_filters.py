from django import template
from django.utils.safestring import mark_safe
from ..utils import get_status_color

register = template.Library()

@register.filter
def get_status_color(status):
    """Filtro para obter a cor do status"""
    from ..utils import get_status_color as get_color
    if not status:
        return "#6c757d"  # Cinza (padrão)
    return get_color(status)


@register.filter
def status_badge(status):
    """Filtro para criar um badge HTML com a cor do status"""
    color = get_status_color(status)
    return mark_safe(
        f'<span class="badge" style="background-color: {color};">{status}</span>'
    )