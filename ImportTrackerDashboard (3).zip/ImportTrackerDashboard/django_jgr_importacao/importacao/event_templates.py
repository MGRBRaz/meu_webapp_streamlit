"""Templates de eventos para atualizações rápidas de status"""

# Dicionário com modelos de descrições para cada status
# Chave: código do status
# Valor: texto do evento

EVENT_TEMPLATES = {
    'novo_processo': "Novo processo de importação iniciado.",
    
    'navio_em_santos': "Navio chegou em Santos. Aguardando desembarque da carga.",
    
    'chegando_porto_santos': "Navio está chegando ao porto de Santos. ETA: {eta}.",
    
    'chegada_navio_alterada': "Chegada do navio alterada. Nova data prevista: {eta}.",
    
    'transito_aduaneiro': "Carga em trânsito aduaneiro. Desembaraço em andamento.",
    
    'rota_transito_aduaneiro': "Carga em rota de trânsito aduaneiro para {destination}.",
    
    'presenca_carga_bauru': "Presença de carga confirmada em Bauru. Aguardando liberação.",
    
    'entrega_programada': "Entrega programada para {delivery_date}."
}

# Função para obter template formatado
def get_event_template(status_code, **kwargs):
    """
    Retorna um template de descrição de evento para o status especificado.
    
    Args:
        status_code: Código do status
        **kwargs: Parâmetros para formatação do template
        
    Returns:
        str: Texto formatado para o evento
    """
    template = EVENT_TEMPLATES.get(status_code)
    
    if not template:
        return f"Status atualizado para: {status_code}"
        
    try:
        return template.format(**kwargs)
    except KeyError:
        # Se faltar algum parâmetro, retorna o template não formatado
        return template