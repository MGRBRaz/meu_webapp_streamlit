from django.urls import path
from . import views

urlpatterns = [
    # Views principais
    path('', views.home, name='home'),
    path('processo/<str:pk>/', views.process_detail, name='process_detail'),
    path('processo/novo/', views.process_create, name='process_create'),
    path('processo/<str:pk>/editar/', views.process_update, name='process_update'),
    path('processo/<str:pk>/excluir/', views.process_delete, name='process_delete'),
    
    # Views de usuários e clientes
    path('usuarios/', views.user_list, name='user_list'),
    path('usuarios/novo/', views.user_create, name='user_create'),
    path('processo/<str:pk>/atribuir/', views.assign_process, name='assign_process'),
    
    # Views de compartilhamento
    path('compartilhar/', views.share_link_create, name='share_link_create'),
    path('compartilhados/<str:token>/', views.shared_process, name='shared_process'),
    path('compartilhamentos/', views.share_link_list, name='share_link_list'),
    path('compartilhamentos/<int:pk>/desativar/', views.share_link_deactivate, name='share_link_deactivate'),
    
    # Views de atualizações rápidas
    path('processo/<str:pk>/status-rapido/', views.quick_status_update, name='quick_status_update'),
    
    # Views de exportação
    path('exportar/', views.export_processes, name='export_processes'),
]