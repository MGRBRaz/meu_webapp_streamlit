from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Process(models.Model):
    """Modelo para processos de importação"""
    
    STATUS_CHOICES = [
        ('em_andamento', 'Em andamento'),
        ('concluido', 'Concluído'),
        ('pendente', 'Pendente'),
        ('atrasado', 'Atrasado'),
        ('cancelado', 'Cancelado'),
        # Status adicionais específicos para importação
        ('novo_processo', 'Novo Processo'),
        ('navio_em_santos', 'Navio em Santos'),
        ('chegando_porto_santos', 'Chegando no porto de Santos'),
        ('chegada_navio_alterada', 'Chegada do navio alterada'),
        ('transito_aduaneiro', 'Trânsito Aduaneiro'),
        ('rota_transito_aduaneiro', 'Em rota de trânsito aduaneiro'),
        ('presenca_carga_bauru', 'Presença de carga em Bauru'),
        ('entrega_programada', 'Entrega programada'),
    ]
    
    # Campos de identificação
    id = models.CharField(max_length=20, primary_key=True)
    ref = models.CharField(max_length=100, blank=True, null=True)
    po = models.CharField(max_length=100, blank=True, null=True)
    invoice = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='em_andamento')
    
    # Campos de origem e produto
    origin = models.CharField(max_length=100, blank=True, null=True)
    product = models.CharField(max_length=200, blank=True, null=True)
    type = models.CharField(max_length=50, blank=True, null=True)
    
    # Campos de transporte
    exporter = models.CharField(max_length=200, blank=True, null=True)
    ship = models.CharField(max_length=100, blank=True, null=True)
    agent = models.CharField(max_length=100, blank=True, null=True)
    bl_number = models.CharField(max_length=100, blank=True, null=True)
    container = models.CharField(max_length=100, blank=True, null=True)
    
    # Campos de datas
    eta = models.DateField(blank=True, null=True)
    arrival_date = models.DateField(blank=True, null=True)
    free_time = models.IntegerField(default=0)
    free_time_expiry = models.DateField(blank=True, null=True)
    empty_return = models.DateField(blank=True, null=True)
    
    # Campos de armazenagem
    terminal = models.CharField(max_length=100, blank=True, null=True)
    port_entry_date = models.DateField(blank=True, null=True)
    current_period_start = models.DateField(blank=True, null=True)
    current_period_expiry = models.DateField(blank=True, null=True)
    storage_days = models.IntegerField(default=0)
    map = models.CharField(max_length=100, blank=True, null=True)
    
    # Campos de documentos
    invoice_number = models.CharField(max_length=100, blank=True, null=True)
    di = models.CharField(max_length=100, blank=True, null=True)
    original_docs = models.CharField(max_length=100, blank=True, null=True)
    return_date = models.DateField(blank=True, null=True)
    
    # Campos adicionais
    observations = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_update = models.DateTimeField(auto_now=True)
    
    # Relações
    client = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='processes'
    )
    
    def __str__(self):
        return f"Processo {self.id} - {self.ref or 'Sem referência'}"
    
    class Meta:
        verbose_name = "Processo de Importação"
        verbose_name_plural = "Processos de Importação"
        ordering = ['-last_update']


class Event(models.Model):
    """Modelo para eventos relacionados a um processo"""
    
    process = models.ForeignKey(
        Process, 
        on_delete=models.CASCADE, 
        related_name='events'
    )
    date = models.DateTimeField(default=timezone.now)
    description = models.TextField()
    user = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True
    )
    
    def __str__(self):
        return f"Evento {self.id} - {self.process.id}"
    
    class Meta:
        verbose_name = "Evento"
        verbose_name_plural = "Eventos"
        ordering = ['-date']


class ShareLink(models.Model):
    """Modelo para links de compartilhamento de processos"""
    
    process = models.ForeignKey(
        Process, 
        on_delete=models.CASCADE, 
        related_name='share_links'
    )
    token = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"Link {self.token} - {self.process.id}"
    
    class Meta:
        verbose_name = "Link de Compartilhamento"
        verbose_name_plural = "Links de Compartilhamento"