from django.contrib import admin
from .models import Process, Event, ShareLink

class EventInline(admin.TabularInline):
    model = Event
    extra = 1
    readonly_fields = ('date',)

class ShareLinkInline(admin.TabularInline):
    model = ShareLink
    extra = 0
    readonly_fields = ('token', 'created_at', 'expires_at', 'is_active')

@admin.register(Process)
class ProcessAdmin(admin.ModelAdmin):
    list_display = ('id', 'ref', 'po', 'status', 'eta', 'client', 'last_update')
    list_filter = ('status', 'client', 'eta')
    search_fields = ('id', 'ref', 'po', 'container', 'invoice', 'product')
    readonly_fields = ('created_at', 'last_update')
    inlines = [EventInline, ShareLinkInline]
    fieldsets = (
        ('Identificação', {
            'fields': ('id', 'ref', 'po', 'invoice', 'status')
        }),
        ('Origem e Produto', {
            'fields': ('origin', 'product', 'type')
        }),
        ('Transporte', {
            'fields': ('exporter', 'ship', 'agent', 'bl_number', 'container')
        }),
        ('Datas', {
            'fields': ('eta', 'arrival_date', 'free_time', 'free_time_expiry', 'empty_return')
        }),
        ('Armazenagem', {
            'fields': ('terminal', 'port_entry_date', 'current_period_start', 'current_period_expiry', 'storage_days', 'map')
        }),
        ('Documentos', {
            'fields': ('invoice_number', 'di', 'original_docs', 'return_date')
        }),
        ('Observações', {
            'fields': ('observations',)
        }),
        ('Cliente', {
            'fields': ('client',)
        }),
        ('Datas de Controle', {
            'fields': ('created_at', 'last_update'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('id', 'process', 'date', 'description', 'user')
    list_filter = ('date', 'user')
    search_fields = ('description', 'process__id')
    readonly_fields = ('date',)

@admin.register(ShareLink)
class ShareLinkAdmin(admin.ModelAdmin):
    list_display = ('id', 'process', 'token', 'created_at', 'expires_at', 'is_active')
    list_filter = ('is_active', 'created_at', 'expires_at')
    search_fields = ('token', 'process__id')
    readonly_fields = ('token', 'created_at')